# Octave implementation of simple Pagerank algorithm

# File to be taken as input
# Note: Should be beside the script
filename = "small.txt";

# Take c as input
c = input("Enter c: ");

# Open file
fid = fopen(filename, "r");

# Calculating the value of n
n=0;
while (!feof(fid))
	n = n+1;
	text_line = fgetl (fid);
endwhile

# Print the value of n computed
printf("\nNumber of pages detected: %d\n\n", n);

# nxn zero matrix
C = zeros(n);

# Parsing the file
# i indicates the number of the line being processed
i = 1;
# Reopen file to begin from the start
fid = fopen (filename, "r");
while (! feof (fid) )
	# Get next line
	text_line = fgetl (fid);
	# Break the line at spaces
	D = strsplit(text_line);
	# The last element being space, the last value is ignored
	D = D(1:length(D)-1);
	num_nonzero=0;
	for x = D
		# Convert string to number so as to index
		y = str2num(x{1,1});
		# following conditions to ensure that graph 
		# have self connections and has no multiple edges
		if ( (y!=i) && (C(y,i)==0) )
			C(y,i) = 1;
			num_nonzero=num_nonzero+1;
		endif
	endfor
	for x = 1:n
		C(x,i) = C(x,i)/num_nonzero;
	endfor
	i = i+1;
endwhile
fclose (fid);

# Considering factor of c
C = C + (c/n)*ones(n);

# Evaluating eigen vector
[eigvect,eigval] = eig(C);

count = 1;
B = diag(eigval); 
#  diag converts nxn matrix to nx1 along diagonal
for x = 1:n
	if (B(x,1) == 1+c)
		count = x;
	endif
endfor
#  finds the index whose eigenvalue is 1+c

# Find the eigvector corresponding to 1+c
wantedranks = eigvect(:,count);

# Sorting of wantedranks
[wantedranksnew,indices] = sort((wantedranks'));

# Normalising condition that sum of ranks is 1
s = sum(wantedranksnew);
for x = 1:n
	wantedranksnew(x) = wantedranksnew(x)/s;
endfor
# normalising the pageranks

# Print the top 20 ranks
for x=1:20
	printf("%d, %f\n",
		indices(x),wantedranksnew(x));
endfor

printf("\n");
