(Rupanshu Ganvir, 140050005) (Sumith, 140050081) (Shubham Goel, 140050086)

Group00: tussle

Contributions:
Rupanshu Ganvir: 100%, Sumith: 100%, Shubham Goel: 100%

The file "small.txt" should be present beside the script "pagerank.m" i.e. in the same directory.

Honour code:
Rupanshu Ganvir
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
Sumith
I pledge on my honour that I will not give or receive any unauthorized assistance for this assignment/task.
Shubham Goel
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

Citations:
1) https://www.gnu.org/software/octave/doc/interpreter/
2) https://piazza.com/class/ic5kd9di29817i?cid=65
3) http://www.math.cornell.edu/~mec/Winter2009/RalucaRemus/Lecture3/lecture3.html
4) http://octave.sourceforge.net/functions_by_alpha.php
5) http://stackoverflow.com/questions/8812674/how-to-share-global-variables-across-multiple-octave-scripts
6) http://stackoverflow.com/questions/4882706/how-can-we-get-user-inputs-from-the-keyboard-in-octave
