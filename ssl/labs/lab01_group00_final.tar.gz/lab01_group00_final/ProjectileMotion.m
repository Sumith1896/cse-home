########OCTAVE#######
##RIP Abdul Kalam####

####Setting Physical Constants####
global diameter = 0.06
global g = 9.81
global k = 0.05

###Basic Unit convesion###
function retval = deg_to_rad(deg)
	retval =  deg*pi/180;
endfunction

###Rounds off theta based on a linear approximation of y###
function change = roundoff(y_prev , y , y1 , y3)
	if((y_prev - y1)*(y - y1) < 0 )
		## y1 lies between y_prev and y ##
		if(abs(y_prev - y1)< abs(y-y1))
			change = -0.01;
		else
			change = 0;
		endif
	else
		if((y_prev - y3)*(y - y3) < 0 )
		## y3 lies between y_prev and y ##
			if(abs(y_prev - y3)< abs(y-y3))
				change = -0.01;
			else
				change = 0;
			endif
		else
		## Handling possible supernatural error :P ##
			change = 0;
		endif
	endif
endfunction

## Case 1 Trajectory ##
function y = case1(angle, a, x)
### a = g*x*x/(2*v*v)  ###
	theta = deg_to_rad(angle);
	tantheta = tan(theta);
	y = (x*tantheta) - a*(1+(tantheta^2));
endfunction


#### Case 2 Trajectory ####
function y = case2(angle, a, b, x)
####  a = g/(k*k) ; b = (k*x)/v  ####
	theta = deg_to_rad(angle);
	tn = tan(theta); sc = sec(theta);
	y = tn*x + a*b*sc + a*log(1-(b*sc));
endfunction


#### Case 3 Trajectory ####
function y = Case3(angle , y_exp, x, g, k, diameter, v)
	theta = deg_to_rad(angle);
	cs = cos(theta);
	sn = sin(theta);
	t = (exp(k*x)-1)/(k*v*cs);
	temp = sqrt(g/k)/(v*cs);
	sqrt_term = sqrt(1 + tan(theta)^2/temp^2);
	term1 = temp*(exp(k*x)-1);
	term2 = atan(tan(theta)/temp);
	costerm = cos(term1 - term2);
	if (costerm < 0)
		## Handling zero error ##
		y=1000000000000000000;
	else
		y = (1/k) * log(sqrt_term*costerm);
	endif
endfunction

## Inputting positions and Velocity ##
x0 = input("Enter x0: ");
y0 = input("Enter y0: ");
xf = input("Enter xf: ");
yf = input("Enter yf: ");
v = input("Enter Velocity: ");

## Calculating frequently used values ##
y2 = yf - y0;
y1 = y2 - (diameter/2);
y3 = y2 + (diameter/2);
x = xf - x0;

###### Calculating starting range for 'for loop' ######
###### Straight line connecting bottom points #########
theta_start = atan(y1/x);
## case1_prev stores if bulls eye was hit on last iiteration ##
## case1_interval_start stores the beginning of interval ##
case1_prev=false;
case1_interval_start = -90.00;

disp("CASE 1 ::");
## Variable Initialization ##
y_prev = -10000000000;
## Calculating 'a' -> often occuring values : (Referred to above) ##
a = (g*x*x)/(2*v*v);
for theta = theta_start:0.01:89.99
	## Point of Impact of projectile at x=xf ##
	y = case1(theta,a,x);
	if (and(y>=y1,y<=y3)== true)## Hits Bulls Eye ##
		if(case1_prev == true)## Valid theta inteval continues ##
		else
			case1_interval_start = theta+ roundoff(y_prev, y , y1, y3); ## Valid theta inteval starts ##
			case1_prev = true;
		endif
	else ## Doesnt hit Bulls Eye ##
		if (case1_prev == true) ## Valid theta inteval ends ##
			temp = theta + roundoff(y_prev, y , y1, y3);
			printf("(%.2f,%.2f)\n",case1_interval_start, temp); ## Printing Answer ##
		else
			if((y_prev-y2)*(y-y2)<=0) ## y2 lies between y_prev and y :: Finding Discreet Values##
				if(abs(y_prev - y2) < abs(y - y2)) ## Linearly Rounding off ##
					printf("[%.2f,%.2f]\n",theta - 0.01, theta - 0.01);
				else	
					printf("[%.2f,%.2f]\n",theta, theta);
				endif
			endif
		endif
		case1_prev = false;
	endif
	y_prev=y;
endfor

case1_prev=false;
case1_interval_start = -90.00;

disp("CASE 2 ::");
## Variable Initialization ##
y_prev = -10000000000;
## Calculating 'a' , 'b' -> often occuring values : (Referred to above) ##
a = g/(k*k); 
b = (k*x)/v;
for theta = theta_start:0.01:89.99
	## Point of Impact of projectile at x=xf ##
	y = case2(theta, a, b, x);
	if (and(y>=y1,y<=y3)== true)## Hits Bulls Eye ##
		if(case1_prev == true)## Valid theta inteval continues ##
		else
			case1_interval_start = theta + roundoff(y_prev, y , y1, y3); ## Valid theta inteval starts ##
			case1_prev = true;
		endif
	else## Doesnt hit Bulls Eye ##
		if (case1_prev == true)## Valid theta inteval ends ##
			temp = theta + roundoff(y_prev, y , y1, y3);
			printf("(%.2f,%.2f)\n",case1_interval_start, temp);## Printing Answer ##
			case1_prev = false;
		else
			if((y_prev-y2)*(y-y2)<=0)## y2 lies between y_prev and y :: Finding Discreet Values##
				if(abs(y_prev - y2) < abs(y - y2))## Linearly Rounding off ##
					printf("[%.2f,%.2f]\n",theta - 0.01, theta - 0.01);
				else	
					printf("[%.2f,%.2f]\n",theta, theta);
				endif
			endif
		endif
		case1_prev = false;
	endif
	y_prev = y;
endfor

case1_prev=false;
case1_interval_start = -90.00;

disp("CASE 3 ::");
## Variable Initialization ##
y_prev = -10000000000;
for theta = theta_start:0.01:89.99
	## Point of Impact of projectile at x=xf ##
	y = Case3(theta, y2, x, g, k, diameter, v);
	if (and(y>=y1,y<=y3) == true)## Hits Bulls Eye ##
		if(case1_prev == true)## Valid theta inteval continues ##
		else
			case1_interval_start = theta + roundoff(y_prev, y , y1, y3);  ## Valid theta inteval starts ##
			case1_prev = true;
		endif
	else ## Doesnt hit Bulls Eye ##
		if (case1_prev == true)## Valid theta inteval ends ##
			temp = theta + roundoff(y_prev, y , y1, y3);
			printf("(%.2f,%.2f)\n",case1_interval_start, temp);## Printing Answer ##
		endif
		case1_prev = false;
	endif
	y_prev = y;
endfor