(Rupanshu Ganvir, 140050005) (Sumith, 140050081) (Shubham Goel, 140050086)

Group00: tussle

Contributions:
Rupanshu Ganvir: 100%, Sumith: 100%, Shubham Goel: 100%

Points to be noted:
1) Canvas is not interactive but high efforts have gone into making that from scratch.
2) 3D view of Yoga and MI room is present in the SAC layout, hovering over objects displays their name.
3) For practice as well as problem requirements, we have made use of three types of CSS styling. We realise there is lack of uniformity but this is done on purpose.

Honour code:
Rupanshu Ganvir
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
Sumith
I pledge on my honour that I will not give or receive any unauthorized assistance for this assignment/task.
Shubham Goel
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

Citations:
1) http://stackoverflow.com/questions/2172798/how-to-draw-an-oval-in-html5-canvas 
2) http://diveintohtml5.info/canvas.html 
3) http://www.w3schools.com 
4) http://inkscape.org/doc/
