(Rupanshu Ganvir, 140050005) (Sumith, 140050081) (Shubham Goel, 140050086)

Group00: tussle

Contributions:
Rupanshu Ganvir: 100%, Sumith: 100%, Shubham Goel: 100%

Points to be noted:
0) PREREQUISITE : freeglut3-dev must be installed to run the challenge.
1) The only modified file is -'dominos.cpp'. The changes are minimalistic:
	a) (line 150)
		Number of balls has been reduced to 1
	b) (line 200) 
		Density of the bar on the other side of the pulley-rope system has been changed to 30.5 from 34.0
   Now, a single small ball is enough to lift up the other bar, and set the remaining mechanism in motion. 

2) Same in this case - 'dominos.cpp' is the only modified file. Changes here are minimalistic as well:
	a) (line 311)
		Density of the bigger block increased to 18.f
	b) (line 312)
		New line added. Friction has been defined to be 0.1f
   Since, the mass of the bigger block is considerably large, it doesn't move much. The other ball
   hence comes over to the right side of the pulley.

3) Challenge Question - 'cs251_base.cpp' and 'cs251_base.hpp' have been modified.
	We have added drag functionality for MULTIPLE dynamic shapes. (Big Square Block, Heavy Sphere, The Plank, The revolving Horizontal Platform etc.)


Honour code: (Please see **Citations First)
Rupanshu Ganvir
I pledge on my honour that I have not given or received any **unauthorized assistance on this assignment or any previous task.
Sumith
I pledge on my honour that I will not give or receive any **unauthorized assistance for this assignment/task.
Shubham Goel
I pledge on my honour that I have not given or received any **unauthorized assistance on this assignment or any previous task.

**Citations:
1) In order to solve the challenge, we have taken help (and code) from the test-cases (/external/src/Box2D/Testbed/) given in the Box2D package. We have got the code working but require further reading for complete insight.