a=`grep "," population.csv`

>population_inc.csv

i=1
for p in $a
do
	line[i]=`echo $p`
	year[i]=`echo ${line[i]} | cut -d"," -f1`
	pop[i]=`echo ${line[i]} | cut -d"," -f2`
	i=$i+1
done

for ((i=1; i <= ${#line[*]} ; i++))
do
	if [ $i -ne 1 ]
	then
		let "diff=${pop[$i]}-${pop[$i-1]}"
		echo "${year[$i]},$diff" >>population_inc.csv
	fi
done