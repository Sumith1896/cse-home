if [ $# -eq 0 ]
then
echo "No arguments"
exit 1
fi

config=~/myopen.cfg
if [ ! -f $config ]
then
	exit 2
fi
filename=`echo $1 | cut -d'.' -f1`
ext=`echo $1 | cut -d'.' -f2`; ext=$ext:

line=`grep $ext ~/myopen.cfg`
if [ $? -ne 0 ] #line not found in cfg
then
exit 3
fi

prgrm=`echo $line | cut -d':' -f2`

$prgrm $1
if [ $? -eq 127 ]
then
exit 4
fi