cat $1 | # get the file
sed 's/\/\/.*$//' | # remove everything after //
grep "include" |  # get all lines with include statements
sed 's/^  *//' |  # remove leading whitespace
grep -e "^#" | # get all beginning with #
sed 's/^#//' | # remove the #
sed 's/^ *//' | # remove the leading spaces
grep "^include" | # get all with include  in the beginning
sed 's/.*<\(.*\)/\1/g' | # remove all before <
sed 's/"/\n/;s/.*\n//' | # remove all before "
sed 's/[>].*$//' | # remove all after >
sed 's/["].*$//'| # remove all after "
sed 's/^ *//' | # remove leading whitespace
sed 's/[ \t]*$//' # remove trailing whitespace