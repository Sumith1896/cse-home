freq=`lscpu | grep "MHz" | awk '{print $3}'`
let phy_address_size=`grep "address sizes" /proc/cpuinfo | awk '{print $4}'`
let virt_address_size=`grep "address sizes" /proc/cpuinfo | awk '{print $7}'`

echo $freq
echo $phy_address_size
echo $virt_address_size