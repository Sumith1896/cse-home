let dir=`ls -p -a | grep -c /`-1
let fil=`ls -p -a | grep -c .`-$dir-1
echo "$fil"
echo "$dir"