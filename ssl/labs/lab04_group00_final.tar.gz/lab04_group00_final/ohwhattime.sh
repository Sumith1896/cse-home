for f in *; 
do
	# echo "$f"
	if [ "$f" != "ohwhattime.sh" ]; then
	
	# timestamp=`get_update_date "$f"`;
	sec=$(date '+%S' -r "$f");
	dat=$(date -r "$f");
	if [ $sec -ge 30 ]; then
		dat=$(date -d "$dat+1 minute");
	fi
	newdate=`date '+_%m_%d_%H:%M' -d "$dat"`;
	new_name=`echo $f$newdate`;
	mv "$f" "$new_name";
	fi
done
