(Rupanshu Ganvir, 140050005) (Sumith, 140050081) (Shubham Goel, 140050086)

Group00: tussle

Contributions:
Rupanshu Ganvir: 100%, Sumith: 100%, Shubham Goel: 100%

Points to be noted:
1) The script file for task 4 has been named task_4.sh. Others as mentioned in the problem statement.

Honour code: (Please see Citations First)
Rupanshu Ganvir
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
Sumith
I pledge on my honour that I will not give or receive any unauthorized assistance for this assignment/task.
Shubham Goel
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

Citations:
1)http://askubuntu.com/questions/218567/any-way-to-check-the-clock-speed-of-my-processor
2)http://www.tldp.org/LDP/tlk/mm/memory.html
3)http://www.linuxquestions.org/questions/linux-hardware-18/address-sizes-in-cpuinfo-757456/
4)http://stackoverflow.com/questions/49403/how-do-you-parse-a-filename-in-bash
5)http://unix.stackexchange.com/questions/49053/linux-add-x-days-to-date-and-get-new-virtual-date
6)http://www.cyberciti.biz/faq/linux-unix-formatting-dates-for-display/
7)http://stackoverflow.com/questions/1024525/how-to-check-if-gcc-has-failed-returned-a-warning-or-succeeded-in-bash
8)http://stackoverflow.com/questions/22287903/handling-gcc-warnings-and-output-in-a-bash-script
