>good.txt
>bad.txt

for file in *.c; 
do
	out={`gcc -Wall -o ${file%.c} $file -lm 2>&1`}
	if [ $? -ne 0 ] 
	then
		echo $file >>bad.txt
	else
		echo $file >>good.txt
	fi
done

#do error reporting as well