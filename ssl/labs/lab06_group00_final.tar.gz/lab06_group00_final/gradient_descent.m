clc;
clear;
format long;

global delta = 0.000000001;
global alpha = 0.1;
global epsilon = 0.0000000000001;
fname = "func";

func_str = input("Enter function: ","s");
str = strrep(func_str,"^","**"); 
global f = inline(func_str,"x","y");

x0 = input("Enter x0: ");
y0 = input("Enter y0: ");
x = x0;
y = y0;

function y = func(x,y)
	global f;
	y = f(x,y);
endfunction

function r = fx(fname,x,y)
	global delta;
	xn = x + delta;
	z2 = feval(fname,xn,y);
	z1 = feval(fname,x,y);
	r = (z2-z1)/delta;
endfunction

function r = fy(fname,x,y)
	global delta;
	z2 = feval(fname,x,y+delta);
	z1 = feval(fname,x,y);
	r = (z2-z1)/delta;
endfunction

# x0 = input("Enter initial x");
# y0 = input("Enter initial y");

A(1,1)=x0;
A(2,1)=y0;
z = feval(fname,A(1,1),A(2,1));
z1 = feval(fname,A(1,1),A(2,1));

i=2;
while(abs(z-z1)>epsilon || i==2)
	A(1,i) = A(1,i-1) - alpha*fx(fname,A(1,i-1),A(2,i-1));
	A(2,i) = A(2,i-1) - alpha*fy(fname,A(1,i-1),A(2,i-1));
	z=z1;
	z1 = feval(fname,A(1,i),A(2,i));
	i=i+1;
endwhile

fid = fopen("output.dat","w");
fprintf(fid,"%s\n",str);
for i = 1:columns(A)
	z = feval(fname,A(1,i),A(2,i));
	fprintf(fid,"%f %f %f\n",A(1,i),A(2,i),z);
endfor

fclose(fid);