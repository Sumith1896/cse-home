(Rupanshu Ganvir, 140050005) (Sumith, 140050081) (Shubham Goel, 140050086)

Group00: tussle

Contributions:
Rupanshu Ganvir: 100%, Sumith: 100%, Shubham Goel: 100%

Honour code: 
Rupanshu Ganvir
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
Sumith
I pledge on my honour that I will not give or receive any unauthorized assistance for this assignment/task.
Shubham Goel
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

Citations:
1)http://www.gnuplot.info/
2)http://sourceforge.net/projects/gnuplot/
3)http://researchweb.iiit.ac.in/~swagatika.panda/Documents/UnicodeText_Latex_Tutorial.pdf
4)pravin.paratey.com/files/devanagari.pdf
5)https://latex-project.org/guides/
6)http://get-software.net/macros/latex/contrib/biblatex/doc/biblatex.pdf