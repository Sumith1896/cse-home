(Rupanshu Ganvir, 140050005) (Sumith, 140050081) (Shubham Goel, 140050086)

Group00: tussle

Contributions:
Rupanshu Ganvir: 100%, Sumith: 100%, Shubham Goel: 100%

How to play:
1) Click on the cell to enter it's value, it has to be between 1 to 9, error is raised.
2) Reset and Check are self-explanatory. 

Honour code:
Rupanshu Ganvir
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
Sumith
I pledge on my honour that I will not give or receive any unauthorized assistance for this assignment/task.
Shubham Goel
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

CITATIONS
http://www.w3schools.com/
http://www.phpied.com/3-ways-to-define-a-javascript-class/
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/forEach
http://stackoverflow.com/questions/3885817/how-to-check-that-a-number-is-float-or-integer