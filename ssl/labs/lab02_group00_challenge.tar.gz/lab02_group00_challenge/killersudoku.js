	var color_cages = [];/////////////
	color_cages.push(new color_cage("yellow",3,[ [0,0] , [0,1] ] ));
	color_cages.push(new color_cage("green",15,[ [0,2] , [0,3] , [0,4] ] ));
	color_cages.push(new color_cage("blue",22,[ [0,5] , [1,4] , [1,5] , [2,4] ] ));
	color_cages.push(new color_cage("green",4,[ [0,6] , [1,6] ]));
	color_cages.push(new color_cage("yellow",16,[ [0,7] , [1,7] ] ));
	color_cages.push(new color_cage("green",15,[ [0,8] , [1,8] , [2,8] , [3,8] ] ));
	color_cages.push(new color_cage("blue",25,[ [1,0] , [1,1] , [2,0] , [2,1] ] ));
	color_cages.push(new color_cage("red",17,[ [1,2] , [1,3] ] ));
	color_cages.push(new color_cage("yellow",9,[ [2,2] , [2,3] , [3,3] ] ));
	color_cages.push(new color_cage("green",8,[ [2,5] , [3,5] , [4,5] ] ));
	color_cages.push(new color_cage("blue",20,[ [2,6] , [3,6] , [2,7] ] ));
	color_cages.push(new color_cage("yellow",6,[ [3,0] , [4,0] ] ));
	color_cages.push(new color_cage("red",14,[ [3,1] , [3,2] ] ));
	color_cages.push(new color_cage("red",17,[ [3,4] , [4,4] , [5,4] ] ));
	color_cages.push(new color_cage("red",17,[ [3,7] , [4,7] , [4,6] ] ));
	color_cages.push(new color_cage("green",13,[ [4,1] , [5,1] , [4,2] ] ));
	color_cages.push(new color_cage("blue",20,[ [4,3] , [5,3] , [6,3] ] ));
	color_cages.push(new color_cage("yellow",12,[ [4,8] , [5,8] ] ));
	color_cages.push(new color_cage("blue",27,[ [5,0] , [6,0] , [7,0] , [8,0] ] ));
	color_cages.push(new color_cage("yellow",6,[ [5,2] , [6,2] , [6,1] ] ));
	color_cages.push(new color_cage("yelow",20,[ [5,5] , [6,5] , [6,6]  ] ));
	color_cages.push(new color_cage("blue",6,[ [5,6] , [5,7] ] ));
	color_cages.push(new color_cage("green",10,[ [6,4] , [7,4] , [7,3] , [8,3] ] ));
	color_cages.push(new color_cage("green",14,[ [6,7] , [6,8] , [7,7] , [7,8] ] ));
	color_cages.push(new color_cage("green",8,[ [7,1] , [8,1] ] ));
	color_cages.push(new color_cage("red",16,[ [7,2] , [8,2] ] ));
	color_cages.push(new color_cage("red",15,[ [7,5] , [7,6] ] ));
	color_cages.push(new color_cage("yellow",13,[ [8,4] , [8,5] , [8,6] ] ));
	color_cages.push(new color_cage("blue",17,[ [8,7] , [8,8] ] ));

	function get_cell(x,y){
		var c =document.getElementById(("c"+ (x+1) ) + (y+1));
		return c;
	}

	function color_cage(color,expected_sum,array){
		this.colour = color;
		this.esum = expected_sum;
		this.cell_elements = array;
	}

	color_cage.prototype.is_valid = function(){
		var sum=0;
		var elements = [];
		for (var k =0 ; k< this.cell_elements.length; k++){
			var cell_n = this.cell_elements[k];
			var c = get_cell(cell_n[0],cell_n[1]);
			var val = c.innerHTML;
			if(val==""){
				return false;
			}
			val = Number(val);
			sum+=val;
			if(elements.indexOf(val)!=-1){
				return false;
			}
			elements.push(val);
		}
		if(this.esum==sum){
			return true;
		}
		else{
			return false;
		}
	};

	function is_box_valid(x1,y1,x2,y2){
		var sum=0;
		var elements = [] ;
		for(var i = x1 ; i < x2; i++){
			// alert("row start" + x1 + i + x2);/////
			for (var j = y1; j<y2; j++ ) {
				var c = get_cell(i,j);
				var val = c.innerHTML;
				// alert(i+","+ j + ":" + val);//////
				if(val==""){
					// alert("returning false b");///
					return false;
				}
				val = parseInt(val);
				// alert(i+","+ j + ":" + val);/////
				sum+=val;
				if(elements.indexOf(val)!=-1){
					// alert("returning true b");
					return false;
				}
				elements.push(val);
			}
			// alert("bbom!!" + i+","+ j + ":" + val);/////
		}
		// alert(i+","+ j + ":" + val);/////
		if(sum == 45){
			// alert("returning true e");
			return true;
		}
		else{
			// alert("returning true e");
			return false;
		}
	}
	
	function isInt(n){
	    return ((Number(n) == n) & ((Number(n) % 1) === 0));
	}

	function validate_input(x){
		if(isInt(x)){
			if(x>0 & x<10){
				return true;
			}
		}
		alert("Incorrect Input Format");
		return false;
	}

	function get_input(id){
		var x = Number(id[2]);
		var y = Number(id[4]);
		var input = prompt("Enter the digit");
		if(input!=null){
			if(validate_input(input)){
				var c = get_cell(x,y);
				c.innerHTML = input;	
			}
			else{
				alert("Input not valid");
			}
			
		}
		else{
			alert("Null input");
		}
	}

	function reset(){
		////////////////
		if(confirm("Are you sure you want to reset the Board?")){
			for (var i=0;i<9;i++){
				for(var j=0;j<9;j++){
					var c = get_cell(i,j);
					c.innerHTML = "";
				}
			}
			alert("Board Reset!");
		}
	}
	
	function check(){
		///////////////
		var status = true;
		for (var k = 0 ; k < color_cages.length; k++){
			var c_cage = (color_cages[k]);
			if (!c_cage.is_valid()){
				status=false;
				break;
			}
		} 
		if(status){
			for(var i =0 ; i<9; i++){
				if(is_box_valid(0,i,9,i+1) == false){
					status = false;
					// alert("nana");
					break;
				}

			}
		}
		if(status){
			for(var i =0 ; i<9; i++){
				if(!is_box_valid(i,0,i+1,9)){
					status = false;
					break;
				}
			}
		}
		if(status){
			for(var i =0 ; i<3; i++){
				for(var j=0;j<3;j++){
					if(!is_box_valid(i*3,j*3,(i+1)*3,(j+1)*3)) {
						status = false;
						break;
					}
				}
				if(status==false){
					break;
				}
			}
		}
		if(status==true){
			alert("Congratulations! You Solved the Sudoku Correctly.");
		}
		else{
			alert("Keep Calm \nand\n Try Again");
		}
	}
