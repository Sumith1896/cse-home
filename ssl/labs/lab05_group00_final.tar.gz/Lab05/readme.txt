(Rupanshu Ganvir, 140050005) (Sumith, 140050081) (Shubham Goel, 140050086)

Group00: tussle

Contributions:
Rupanshu Ganvir: 100%, Sumith: 100%, Shubham Goel: 100%

Points to be noted:

Honour code: 
Rupanshu Ganvir
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.
Sumith
I pledge on my honour that I will not give or receive any unauthorized assistance for this assignment/task.
Shubham Goel
I pledge on my honour that I have not given or received any unauthorized assistance on this assignment or any previous task.

Citations:
1) http://mrbook.org/blog/tutorials/make/
2) http://www.cs.colby.edu/maxwell/courses/tutorials/maketutor/
3) http://stackoverflow.com/
4) http://www.cmake.org/